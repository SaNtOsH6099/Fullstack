# ReactJS - Hello World (Task 24)

ReactJS - Hello World

Click the link below to see the live deployment:
[https://santosh6099.github.io/Fullstack/React/01-hello-world/](https://santosh6099.github.io/Fullstack/React/01-hello-world/)

# How to run

1. Open the project folder in your code editor.
2. Open the terminal in that folder.
3. Run: `npm install`
4. Run: `npm run dev`
5. Open the local URL shown in the terminal in your browser.
6. If needed, press the browser refresh button to confirm the page is working.

# Submission instructions

- Do not use AI.
- Test the page in the browser.
- Add this README.md file inside the project folder.
- Delete node_modules before compressing the folder.
- Compress the folder into a .zip file.
- Rename the file as: `SantoshChandra_Task24.zip`
- Upload the ZIP file to the submission portal.
